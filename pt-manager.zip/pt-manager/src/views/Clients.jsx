import React, { useState } from 'react'
import { Card, Btn, Avatar, Empty, SecTitle } from '../components/UI.jsx'
import { fmtDate } from '../lib/store.js'

export default function Clients({ clients, cards, onNavigate, onAddClient, onDeleteClient }) {
  const [search, setSearch] = useState('')
  const filtered = clients.filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()))
  const clientCards = (cid) => cards.filter(c => c.clientId === cid && !c.isTemplate)

  return (
    <div className='anim' style={{ maxWidth:820, margin:'0 auto', padding:'22px 16px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
        <div style={{ fontFamily:'var(--fontcd)', fontSize:22, fontWeight:900 }}>
          Clienti <span style={{ color:'var(--muted)', fontSize:15, fontWeight:400 }}>({clients.length})</span>
        </div>
        <Btn onClick={onAddClient}>+ Nuovo cliente</Btn>
      </div>

      <input value={search} onChange={e=>setSearch(e.target.value)} placeholder='🔍 Cerca cliente...'
        style={{ marginBottom:14 }} />

      {filtered.length === 0 ? (
        <Empty>
          {search ? 'Nessun cliente trovato.' : 'Nessun cliente ancora.'}<br />
          {!search && <Btn variant='primary' style={{ marginTop:12 }} onClick={onAddClient}>+ Aggiungi cliente</Btn>}
        </Empty>
      ) : filtered.map(cl => (
        <Card key={cl.id} style={{ padding:'12px 15px', marginBottom:8, display:'flex', alignItems:'center', gap:11, cursor:'pointer', transition:'border-color .15s' }}
          onClick={() => onNavigate('client-detail', { clientId: cl.id })}
          onMouseEnter={e => e.currentTarget.style.borderColor='var(--borderhi)'}
          onMouseLeave={e => e.currentTarget.style.borderColor='var(--border)'}>
          <Avatar name={cl.name} />
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:700, fontSize:14 }}>{cl.name || 'Senza nome'}</div>
            <div style={{ color:'var(--muted)', fontSize:11 }}>{cl.level}{cl.goal ? ` • ${cl.goal}` : ''}</div>
          </div>
          <div style={{ textAlign:'right' }}>
            <div style={{ color:'var(--gold)', fontWeight:700, fontSize:13 }}>{clientCards(cl.id).length} schede</div>
            <div style={{ color:'var(--muted)', fontSize:11 }}>Dal {fmtDate(cl.createdAt)}</div>
          </div>
          <button onClick={e => { e.stopPropagation(); onDeleteClient(cl.id) }}
            style={{ background:'rgba(230,57,70,.1)', border:'1px solid var(--accent)', color:'var(--accent)', borderRadius:6, padding:'4px 9px', fontSize:11, fontWeight:700, cursor:'pointer' }}>✕</button>
        </Card>
      ))}
    </div>
  )
}
