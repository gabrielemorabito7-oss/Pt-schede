import React, { useState, useCallback } from 'react'
import { Card, Btn, Field, Grid, SecTitle, Tag } from '../components/UI.jsx'
import DayCard from '../components/DayCard.jsx'
import { LEVELS, newDay } from '../lib/store.js'

export default function CardEditor({ card: initialCard, client, trainer, onBack, onSave, onGeneratePDF, onClone, onSaveAsTemplate }) {
  const [card, setCard] = useState(() => JSON.parse(JSON.stringify(initialCard)))
  const upd = (k, v) => setCard(c => ({ ...c, [k]: v }))

  const updateDay = (i, d) => setCard(c => { const days=[...c.days]; days[i]=d; return {...c,days} })
  const removeDay = (i) => setCard(c => ({ ...c, days: c.days.filter((_,j)=>j!==i) }))
  const addDay = () => setCard(c => ({ ...c, days: [...c.days, newDay()] }))

  const handleSave = () => onSave(card)

  const backLabel = client ? client.name : (card.isTemplate ? 'Template' : 'Schede')

  return (
    <div className='anim' style={{ maxWidth:820, margin:'0 auto', padding:'22px 16px' }}>
      {/* Top bar */}
      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:18, flexWrap:'wrap' }}>
        <Btn variant='ghost' size='sm' onClick={() => { handleSave(); onBack(); }}>← {backLabel}</Btn>
        {card.isTemplate && <Tag color='var(--gold)' bg='var(--goldlo)'>TEMPLATE</Tag>}
        <div style={{ flex:1 }} />
        <Btn variant='ghost' size='sm' onClick={() => onClone(card.id, card.clientId)}>⧉ Duplica</Btn>
        {!card.isTemplate && <Btn variant='ghost' size='sm' onClick={() => onSaveAsTemplate(card.id)}>📑 Template</Btn>}
        {!card.isTemplate && client && <Btn variant='teal' size='sm' onClick={() => onGeneratePDF(card.id)}>📄 PDF</Btn>}
        <Btn onClick={handleSave}>💾 Salva</Btn>
      </div>

      {/* Card meta */}
      <Card style={{ padding:16, marginBottom:16 }}>
        <SecTitle>Informazioni scheda</SecTitle>
        <Grid cols={4} style={{ marginBottom:10 }}>
          <Field label='Titolo' value={card.title} onChange={v=>upd('title',v)} placeholder='Scheda Ipertrofia A' />
          <Field label='Livello' value={card.level} onChange={v=>upd('level',v)} options={LEVELS} />
          <Field label='Settimane' value={card.weeks} onChange={v=>upd('weeks',v)} placeholder='8' />
          <Field label='Data inizio' value={card.startDate} onChange={v=>upd('startDate',v)} type='date' />
        </Grid>
        <div style={{ marginBottom:10 }}>
          <Field label='Obiettivo' value={card.goal} onChange={v=>upd('goal',v)} placeholder='Ipertrofia, Forza, Dimagrimento...' />
        </div>
        <Field label='📋 Note generali' value={card.generalNotes} onChange={v=>upd('generalNotes',v)}
          placeholder='Infortuni, avvertenze, indicazioni generali...' textarea />
      </Card>

      {/* Days */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
        <SecTitle style={{ marginBottom:0 }}>⚡ Giorni di allenamento ({card.days.length})</SecTitle>
        <Btn size='sm' onClick={addDay}>+ Giorno</Btn>
      </div>

      {card.days.map((day, i) => (
        <DayCard key={day.id} day={day} idx={i} total={card.days.length}
          onChange={d => updateDay(i, d)}
          onRemove={() => removeDay(i)} />
      ))}

      {/* Bottom actions */}
      <div style={{ textAlign:'center', padding:'20px 0 8px', display:'flex', justifyContent:'center', gap:10 }}>
        <Btn size='lg' onClick={handleSave}>💾 Salva scheda</Btn>
        {!card.isTemplate && client && (
          <Btn variant='teal' size='lg' onClick={() => onGeneratePDF(card.id)}>📄 Genera PDF</Btn>
        )}
      </div>
    </div>
  )
}
