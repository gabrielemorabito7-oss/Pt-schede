import React from 'react'
import { Card, SecTitle, Avatar, Empty, Btn } from '../components/UI.jsx'
import { fmtDate } from '../lib/store.js'

export default function Dashboard({ clients, cards, templates, onNavigate }) {
  const nonTemplate = cards.filter(c => !c.isTemplate)
  const recent = clients.slice(-5).reverse()
  const clientCards = (cid) => nonTemplate.filter(c => c.clientId === cid)

  return (
    <div className='anim' style={{ maxWidth:820, margin:'0 auto', padding:'22px 16px' }}>
      {/* Welcome */}
      <div style={{ marginBottom:22 }}>
        <div style={{ color:'var(--muted)', fontSize:10, fontWeight:700, letterSpacing:'.1em', textTransform:'uppercase', marginBottom:5 }}>Dashboard</div>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:26 }}>
        {[
          { label:'Clienti', val:clients.length, icon:'👤', color:'var(--teal)', view:'clients' },
          { label:'Schede', val:nonTemplate.length, icon:'📋', color:'var(--gold)', view:'cards' },
          { label:'Template', val:templates.length, icon:'📑', color:'var(--accent)', view:'templates' },
        ].map(s => (
          <Card key={s.label} style={{ padding:'16px 18px', cursor:'pointer' }} onClick={() => onNavigate(s.view)}>
            <div style={{ fontSize:22, marginBottom:5 }}>{s.icon}</div>
            <div style={{ fontFamily:'var(--fontcd)', fontSize:32, fontWeight:900, color:s.color, lineHeight:1 }}>{s.val}</div>
            <div style={{ color:'var(--muted)', fontSize:11, marginTop:3 }}>{s.label}</div>
          </Card>
        ))}
      </div>

      {/* Recent clients */}
      <SecTitle>Clienti recenti</SecTitle>
      {recent.length === 0 ? (
        <Empty>
          Nessun cliente ancora.<br />
          <Btn variant='primary' style={{ marginTop:12 }} onClick={() => onNavigate('clients')}>+ Aggiungi cliente</Btn>
        </Empty>
      ) : recent.map(cl => (
        <Card key={cl.id} style={{ padding:'12px 15px', marginBottom:8, display:'flex', alignItems:'center', gap:11, cursor:'pointer', transition:'border-color .15s' }}
          onClick={() => onNavigate('client-detail', { clientId: cl.id })}
          onMouseEnter={e => e.currentTarget.style.borderColor='var(--borderhi)'}
          onMouseLeave={e => e.currentTarget.style.borderColor='var(--border)'}>
          <Avatar name={cl.name} />
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:700, fontSize:14 }}>{cl.name || 'Senza nome'}</div>
            <div style={{ color:'var(--muted)', fontSize:11 }}>{cl.goal || cl.level} • {clientCards(cl.id).length} schede</div>
          </div>
          <div style={{ color:'var(--muted)', fontSize:11 }}>{fmtDate(cl.createdAt)}</div>
          <span style={{ color:'var(--muted)', fontSize:18 }}>›</span>
        </Card>
      ))}
    </div>
  )
}
