import React, { useState, useRef } from 'react'
import { Card, Btn, Field, SecTitle } from '../components/UI.jsx'

export default function Settings({ trainer, clients, cards, templates, onSaveTrainer, onExport, onImport }) {
  const [t, setT] = useState({ ...trainer })
  const fileRef = useRef()

  const handleImport = (e) => {
    const file = e.target.files[0]
    if (!file) return
    const r = new FileReader()
    r.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target.result)
        onImport(data)
      } catch { alert('File non valido.') }
    }
    r.readAsText(file)
    e.target.value = ''
  }

  return (
    <div className='anim' style={{ maxWidth:560, margin:'0 auto', padding:'22px 16px' }}>
      <div style={{ fontFamily:'var(--fontcd)', fontSize:22, fontWeight:900, marginBottom:20 }}>Impostazioni</div>

      <Card style={{ padding:16, marginBottom:14 }}>
        <SecTitle>Dati trainer</SecTitle>
        <div style={{ marginBottom:10 }}>
          <Field label='Il tuo nome' value={t.name} onChange={v=>setT(x=>({...x,name:v}))} placeholder='Gabri PT' />
        </div>
        <div style={{ marginBottom:12 }}>
          <Field label='Contatto / Instagram / Palestra' value={t.contact} onChange={v=>setT(x=>({...x,contact:v}))} placeholder='@gabri.pt / +39 333...' />
        </div>
        <Btn onClick={() => onSaveTrainer(t)}>Salva</Btn>
        <div style={{ color:'var(--muted)', fontSize:11, marginTop:8 }}>Appaiono in fondo ad ogni PDF generato.</div>
      </Card>

      <Card style={{ padding:16, marginBottom:14 }}>
        <SecTitle>Database locale</SecTitle>
        <div style={{ color:'var(--mutedhi)', fontSize:12, marginBottom:14 }}>
          {clients.length} clienti &nbsp;•&nbsp; {cards.filter(c=>!c.isTemplate).length} schede &nbsp;•&nbsp; {templates.length} template
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          <Btn variant='ghost' onClick={onExport} style={{ textAlign:'left' }}>📤 Esporta backup JSON</Btn>
          <Btn variant='ghost' onClick={() => fileRef.current.click()} style={{ textAlign:'left' }}>📥 Importa backup JSON</Btn>
          <input ref={fileRef} type='file' accept='.json' style={{ display:'none' }} onChange={handleImport} />
        </div>
      </Card>

      <Card style={{ padding:16 }}>
        <SecTitle>Installa come app</SecTitle>
        <div style={{ color:'var(--mutedhi)', fontSize:12.5, lineHeight:1.8 }}>
          <strong style={{ color:'var(--text)' }}>Su iPad / iPhone:</strong><br />
          Apri in Safari → Condividi ↑ → <em>Aggiungi alla schermata Home</em><br /><br />
          <strong style={{ color:'var(--text)' }}>Su Mac / PC:</strong><br />
          Chrome/Edge → icona installa nella barra indirizzi
        </div>
      </Card>
    </div>
  )
}
