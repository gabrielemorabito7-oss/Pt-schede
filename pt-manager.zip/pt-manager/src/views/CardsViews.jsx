import React, { useState } from 'react'
import { Card, Btn, Empty, SecTitle } from '../components/UI.jsx'
import { fmtDate } from '../lib/store.js'

export function AllCards({ cards, clients, onOpenCard, onCloneCard, onSaveAsTemplate, onDeleteCard, onGeneratePDF }) {
  const [search, setSearch] = useState('')
  const nonTemplate = cards.filter(c => !c.isTemplate)
  const filtered = nonTemplate.filter(c => {
    if (!search) return true
    const cl = clients.find(x => x.id === c.clientId)
    return c.title.toLowerCase().includes(search.toLowerCase()) ||
           (cl && cl.name.toLowerCase().includes(search.toLowerCase()))
  })

  return (
    <div className='anim' style={{ maxWidth:820, margin:'0 auto', padding:'22px 16px' }}>
      <div style={{ fontFamily:'var(--fontcd)', fontSize:22, fontWeight:900, marginBottom:16 }}>
        Tutte le schede <span style={{ color:'var(--muted)', fontSize:15, fontWeight:400 }}>({nonTemplate.length})</span>
      </div>
      <input value={search} onChange={e=>setSearch(e.target.value)} placeholder='🔍 Cerca scheda o cliente...' style={{ marginBottom:14 }} />

      {filtered.length === 0 ? <Empty>Nessuna scheda{search ? ' trovata' : ''}.</Empty> :
        filtered.map(card => {
          const cl = clients.find(c => c.id === card.clientId)
          return (
            <Card key={card.id} style={{ padding:'12px 15px', marginBottom:8, display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
              <div style={{ flex:1, minWidth:150, cursor:'pointer' }} onClick={() => onOpenCard(card.id)}>
                <div style={{ fontWeight:700, fontSize:13 }}>{card.title}</div>
                {cl && <div style={{ color:'var(--teal)', fontSize:11, fontWeight:700 }}>{cl.name}</div>}
                <div style={{ color:'var(--muted)', fontSize:11 }}>{card.level}{card.goal ? ` • ${card.goal}` : ''} • {card.days.length} giorni</div>
                <div style={{ color:'var(--muted)', fontSize:10, marginTop:2 }}>Aggiornata {fmtDate(card.updatedAt)}</div>
              </div>
              <div style={{ display:'flex', gap:5, flexWrap:'wrap' }}>
                <Btn variant='ghost' size='sm' onClick={() => onCloneCard(card.id, card.clientId)}>⧉</Btn>
                <Btn variant='ghost' size='sm' onClick={() => onSaveAsTemplate(card.id)}>📑</Btn>
                <Btn variant='teal' size='sm' onClick={() => onGeneratePDF(card.id)}>📄 PDF</Btn>
                <Btn size='sm' onClick={() => onOpenCard(card.id)}>Modifica</Btn>
                <Btn variant='danger' size='sm' onClick={() => onDeleteCard(card.id)}>✕</Btn>
              </div>
            </Card>
          )
        })}
    </div>
  )
}

export function Templates({ templates, clients, onOpenCard, onApplyTemplate, onDeleteCard, onCreateTemplate }) {
  return (
    <div className='anim' style={{ maxWidth:820, margin:'0 auto', padding:'22px 16px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
        <div style={{ fontFamily:'var(--fontcd)', fontSize:22, fontWeight:900 }}>
          Template <span style={{ color:'var(--muted)', fontSize:15, fontWeight:400 }}>({templates.length})</span>
        </div>
        <Btn onClick={onCreateTemplate}>+ Nuovo template</Btn>
      </div>
      <div style={{ color:'var(--muted)', fontSize:12, marginBottom:18, lineHeight:1.6 }}>
        Schede riutilizzabili. Applicale a qualsiasi cliente in un click.
      </div>

      {templates.length === 0 ? (
        <Empty>Nessun template. Creane uno o salva una scheda esistente come template.</Empty>
      ) : templates.map(t => (
        <Card key={t.id} style={{ padding:'12px 15px', marginBottom:8, display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
          <div style={{ width:34, height:34, borderRadius:7, background:'var(--goldlo)', border:'1px solid var(--gold)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, flexShrink:0 }}>📑</div>
          <div style={{ flex:1, minWidth:120, cursor:'pointer' }} onClick={() => onOpenCard(t.id)}>
            <div style={{ fontWeight:700, fontSize:13 }}>{t.title}</div>
            <div style={{ color:'var(--muted)', fontSize:11 }}>{t.level}{t.goal ? ` • ${t.goal}` : ''} • {t.days.length} giorni{t.weeks ? ` • ${t.weeks} sett.` : ''}</div>
          </div>
          <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
            {clients.length > 0 && (
              <select onChange={e => { if(e.target.value) { onApplyTemplate(t.id, e.target.value); e.target.value=''; }}}
                style={{ fontSize:11, padding:'5px 9px', width:'auto', cursor:'pointer' }}>
                <option value=''>Applica a...</option>
                {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            )}
            <Btn size='sm' onClick={() => onOpenCard(t.id)}>Modifica</Btn>
            <Btn variant='danger' size='sm' onClick={() => onDeleteCard(t.id)}>✕</Btn>
          </div>
        </Card>
      ))}
    </div>
  )
}
