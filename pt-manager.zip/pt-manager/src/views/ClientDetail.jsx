import React, { useState } from 'react'
import { Card, Btn, Field, Grid, SecTitle, Empty, Tag } from '../components/UI.jsx'
import { fmtDate, LEVELS } from '../lib/store.js'

export default function ClientDetail({ client, cards, templates, trainer, onBack, onSaveClient, onDeleteClient, onCreateCard, onOpenCard, onCloneCard, onSaveAsTemplate, onApplyTemplate, onDeleteCard, onGeneratePDF }) {
  const [editing, setEditing] = useState({ ...client })
  const upd = (k, v) => setEditing(e => ({ ...e, [k]: v }))
  const ccards = cards.filter(c => c.clientId === client.id && !c.isTemplate)

  const handleSave = () => onSaveClient(editing)

  return (
    <div className='anim' style={{ maxWidth:820, margin:'0 auto', padding:'22px 16px' }}>
      {/* Top */}
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:20, flexWrap:'wrap' }}>
        <Btn variant='ghost' size='sm' onClick={onBack}>← Clienti</Btn>
        <div style={{ flex:1, fontFamily:'var(--fontcd)', fontSize:20, fontWeight:900 }}>{client.name || 'Cliente'}</div>
        <Btn onClick={handleSave}>Salva</Btn>
      </div>

      {/* Edit form */}
      <Card style={{ padding:16, marginBottom:18 }}>
        <SecTitle>Dati cliente</SecTitle>
        <Grid cols={3} style={{ marginBottom:10 }}>
          <Field label='Nome & Cognome' value={editing.name} onChange={v=>upd('name',v)} placeholder='Mario Rossi' />
          <Field label='Età' value={editing.age} onChange={v=>upd('age',v)} placeholder='28' />
          <Field label='Livello' value={editing.level} onChange={v=>upd('level',v)} options={LEVELS} />
        </Grid>
        <Grid cols={2} style={{ marginBottom:10 }}>
          <Field label='Email' value={editing.email} onChange={v=>upd('email',v)} placeholder='mario@email.com' type='email' />
          <Field label='Telefono' value={editing.phone} onChange={v=>upd('phone',v)} placeholder='+39 333...' />
        </Grid>
        <div style={{ marginBottom:10 }}>
          <Field label='Obiettivo' value={editing.goal} onChange={v=>upd('goal',v)} placeholder='Ipertrofia / Dimagrimento / Forza...' />
        </div>
        <Field label='Note' value={editing.notes} onChange={v=>upd('notes',v)} placeholder='Infortuni, limitazioni, preferenze mediche...' textarea />
      </Card>

      {/* Cards section */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10, flexWrap:'wrap', gap:8 }}>
        <SecTitle style={{ marginBottom:0 }}>Schede ({ccards.length})</SecTitle>
        <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
          {templates.length > 0 && (
            <select onChange={e => { if(e.target.value) { onApplyTemplate(e.target.value, client.id); e.target.value=''; }}}
              style={{ fontSize:12, padding:'6px 10px', width:'auto', cursor:'pointer' }}>
              <option value=''>📑 Da template...</option>
              {templates.map(t => <option key={t.id} value={t.id}>{t.title}</option>)}
            </select>
          )}
          <Btn size='sm' onClick={() => onCreateCard(client.id)}>+ Nuova scheda</Btn>
        </div>
      </div>

      {ccards.length === 0 ? (
        <Empty>Nessuna scheda. Creane una o applica un template.</Empty>
      ) : ccards.map(card => (
        <Card key={card.id} style={{ padding:'12px 15px', marginBottom:8, display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
          <div style={{ flex:1, minWidth:150, cursor:'pointer' }} onClick={() => onOpenCard(card.id)}>
            <div style={{ fontWeight:700, fontSize:13 }}>{card.title}</div>
            <div style={{ color:'var(--muted)', fontSize:11 }}>{card.level}{card.goal ? ` • ${card.goal}` : ''} • {card.days.length} giorni{card.weeks ? ` • ${card.weeks} sett.` : ''}</div>
            <div style={{ color:'var(--muted)', fontSize:10, marginTop:2 }}>Aggiornata {fmtDate(card.updatedAt)}</div>
          </div>
          <div style={{ display:'flex', gap:5, flexWrap:'wrap' }}>
            <Btn variant='ghost' size='sm' title='Duplica' onClick={() => onCloneCard(card.id, client.id)}>⧉</Btn>
            <Btn variant='ghost' size='sm' title='Salva come template' onClick={() => onSaveAsTemplate(card.id)}>📑</Btn>
            <Btn variant='teal' size='sm' onClick={() => onGeneratePDF(card.id)}>📄 PDF</Btn>
            <Btn size='sm' onClick={() => onOpenCard(card.id)}>Modifica</Btn>
            <Btn variant='danger' size='sm' onClick={() => onDeleteCard(card.id)}>✕</Btn>
          </div>
        </Card>
      ))}

      <div style={{ marginTop:20, paddingTop:16, borderTop:'1px solid var(--border)' }}>
        <button onClick={() => onDeleteClient(client.id)}
          style={{ background:'transparent', border:'none', color:'var(--muted)', fontSize:12, cursor:'pointer', fontFamily:'var(--font)' }}>
          🗑 Elimina cliente
        </button>
      </div>
    </div>
  )
}
