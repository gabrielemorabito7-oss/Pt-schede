import React, { useState } from 'react'
import { Field, Btn, SecTitle } from './UI.jsx'
import ExerciseRow from './ExerciseRow.jsx'
import { newExercise } from '../lib/store.js'
import { MUSCLES, DAYS_W } from '../lib/store.js'

export default function DayCard({ day, idx, total, onChange, onRemove }) {
  const [open, setOpen] = useState(true)
  const upd = (k, v) => onChange({ ...day, [k]: v })

  const updEx = (i, ex) => {
    const exercises = [...day.exercises]
    exercises[i] = ex
    onChange({ ...day, exercises })
  }
  const remEx = (i) => onChange({ ...day, exercises: day.exercises.filter((_, j) => j !== i) })
  const addEx = () => onChange({ ...day, exercises: [...day.exercises, newExercise()] })

  return (
    <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:12, marginBottom:12, overflow:'hidden' }}>
      {/* Day header */}
      <div onClick={() => setOpen(!open)} style={{
        padding:'11px 15px', display:'flex', alignItems:'center', gap:9, cursor:'pointer',
        background:'linear-gradient(90deg,var(--acclo),transparent)',
        borderBottom: open ? '1px solid var(--border)' : 'none',
      }}>
        <div style={{ background:'var(--accent)', color:'#fff', borderRadius:5, padding:'3px 9px', fontSize:10, fontWeight:800, flexShrink:0 }}>
          GIORNO {idx + 1}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontWeight:700, fontSize:13, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
            {day.label || 'Senza titolo'}{day.muscleGroup ? ` — ${day.muscleGroup}` : ''}
          </div>
          <div style={{ color:'var(--muted)', fontSize:11 }}>
            {day.exercises.length} esercizi{day.weekDay ? ` • ${day.weekDay}` : ''}
          </div>
        </div>
        <span style={{ color:'var(--muted)', fontSize:12 }}>{open ? '▲' : '▼'}</span>
        {total > 1 && (
          <Btn variant='danger' size='sm' onClick={e => { e.stopPropagation(); onRemove() }}>Rimuovi</Btn>
        )}
      </div>

      {open && (
        <div style={{ padding:16 }}>
          {/* Meta */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:9, marginBottom:10 }}>
            <Field label='Titolo sessione' value={day.label} onChange={v=>upd('label',v)} placeholder='Push / Upper A...' />
            <Field label='Muscoli' value={day.muscleGroup} onChange={v=>upd('muscleGroup',v)} options={MUSCLES} />
            <Field label='Giorno' value={day.weekDay} onChange={v=>upd('weekDay',v)} options={DAYS_W} />
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:9, marginBottom:10 }}>
            <Field label='🔥 Riscaldamento' value={day.warmup} onChange={v=>upd('warmup',v)} placeholder='10 min cyclette + mobilità' textarea rows={2} />
            <Field label='🧘 Cooldown' value={day.cooldown} onChange={v=>upd('cooldown',v)} placeholder='Stretching 10 min' textarea rows={2} />
          </div>

          <SecTitle>⚡ Esercizi</SecTitle>

          {day.exercises.map((ex, i) => (
            <ExerciseRow key={ex.id} ex={ex} idx={i}
              onChange={upd => updEx(i, upd)}
              onRemove={() => remEx(i)} />
          ))}

          <button onClick={addEx} style={{
            width:'100%', padding:9, background:'transparent', border:'1.5px dashed var(--border)',
            borderRadius:7, color:'var(--muted)', cursor:'pointer', fontSize:12, marginBottom:10,
            fontFamily:'var(--font)',
          }}>
            + Aggiungi esercizio
          </button>

          <Field label='📋 Note giornata' value={day.dayNotes} onChange={v=>upd('dayNotes',v)}
            placeholder='Note specifiche per questa sessione...' textarea rows={2} />
        </div>
      )}
    </div>
  )
}
