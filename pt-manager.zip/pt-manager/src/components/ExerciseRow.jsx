import React, { useState } from 'react'
import { Field } from './UI.jsx'

const PARAMS = [
  ['Serie','sets','3'],
  ['Rip.','reps','10-12'],
  ['Recupero','rest','60s'],
  ['Carico','weight','kg/%'],
  ['RPE','rpe','7'],
  ['Tempo','tempo','2-0-2'],
]

export default function ExerciseRow({ ex, idx, onChange, onRemove }) {
  const [open, setOpen] = useState(true)
  const upd = (k, v) => onChange({ ...ex, [k]: v })

  return (
    <div style={{ background:'#0a0a14', border:'1px solid var(--border)', borderRadius:8, marginBottom:8, overflow:'hidden' }}>
      {/* Header */}
      <div onClick={() => setOpen(!open)} style={{
        padding:'9px 12px', display:'flex', alignItems:'center', gap:8, cursor:'pointer',
        background: open ? 'var(--acclo)' : 'transparent',
        borderBottom: open ? '1px solid var(--border)' : 'none',
      }}>
        <div style={{ background:'var(--accent)', color:'#fff', borderRadius:5, width:22, height:22, display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:900, flexShrink:0 }}>
          {idx + 1}
        </div>
        <span style={{ flex:1, color: ex.name ? 'var(--text)' : 'var(--muted)', fontSize:13, fontWeight:600 }}>
          {ex.name || 'Esercizio senza nome'}
        </span>
        {ex.sets && ex.reps && (
          <span style={{ color:'var(--gold)', fontSize:11, fontWeight:800 }}>{ex.sets}×{ex.reps}</span>
        )}
        {ex.rest && (
          <span style={{ color:'var(--teal)', fontSize:11, background:'var(--teallo)', padding:'2px 6px', borderRadius:4 }}>↩ {ex.rest}</span>
        )}
        {ex.youtubeUrl && <span style={{ color:'var(--accent)', fontSize:12 }}>▶</span>}
        <span style={{ color:'var(--muted)', fontSize:11 }}>{open ? '▲' : '▼'}</span>
        <button onClick={e => { e.stopPropagation(); onRemove() }}
          style={{ background:'none', border:'none', color:'var(--muted)', cursor:'pointer', fontSize:15, padding:0, lineHeight:1 }}>✕</button>
      </div>

      {open && (
        <div style={{ padding:12 }}>
          {/* Name */}
          <div style={{ marginBottom:9 }}>
            <Field label='Nome esercizio' value={ex.name} onChange={v=>upd('name',v)} placeholder='es. Squat con bilanciere' />
          </div>

          {/* Params grid */}
          <div style={{ display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap:6, marginBottom:9 }}>
            {PARAMS.map(([l,k,p]) => (
              <div key={k}>
                <label style={{ color:'var(--muted)', fontSize:9.5, fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase', marginBottom:3, display:'block' }}>{l}</label>
                <input value={ex[k]} onChange={e=>upd(k,e.target.value)} placeholder={p}
                  style={{ fontSize:11.5, padding:'5px 7px', width:'100%', background:'#0a0a14', border:'1px solid var(--border)', borderRadius:6, color:'var(--text)', outline:'none', fontFamily:'var(--font)' }} />
              </div>
            ))}
          </div>

          {/* Links */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:9 }}>
            <Field label='🎬 Link YouTube' value={ex.youtubeUrl} onChange={v=>upd('youtubeUrl',v)} placeholder='https://youtu.be/...' />
            <Field label='🖼 URL Immagine' value={ex.imageUrl} onChange={v=>upd('imageUrl',v)} placeholder='https://...' />
          </div>

          {/* Notes */}
          <Field label='📝 Note tecniche' value={ex.notes} onChange={v=>upd('notes',v)}
            placeholder='Tecnica, grip, posizione, errori comuni...' textarea rows={2} />
        </div>
      )}
    </div>
  )
}
