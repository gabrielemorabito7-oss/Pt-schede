import React from 'react'

// ─── Buttons ──────────────────────────────────────────────────────────────────
const variants = {
  primary: { background:'var(--accent)', color:'#fff', border:'none' },
  ghost:   { background:'transparent', color:'var(--mutedhi)', border:'1px solid var(--border)' },
  teal:    { background:'var(--teallo)', color:'var(--teal)', border:'1px solid var(--teal)' },
  gold:    { background:'var(--goldlo)', color:'var(--gold)', border:'1px solid var(--gold)' },
  danger:  { background:'rgba(230,57,70,.1)', color:'var(--accent)', border:'1px solid var(--accent)' },
}

export function Btn({ children, variant='primary', size='md', style={}, ...props }) {
  const sz = size==='sm' ? {padding:'5px 10px',fontSize:11} : size==='lg' ? {padding:'11px 26px',fontSize:15} : {padding:'7px 14px',fontSize:13}
  return (
    <button style={{ borderRadius:7, fontWeight:700, fontFamily:'var(--font)', cursor:'pointer', whiteSpace:'nowrap',
      ...variants[variant], ...sz, ...style }} {...props}>
      {children}
    </button>
  )
}

// ─── Field ────────────────────────────────────────────────────────────────────
export function Field({ label, value, onChange, type='text', placeholder='', textarea=false, options=null, rows=3, style={} }) {
  const inputStyle = { ...style }
  return (
    <div>
      {label && <label style={{ color:'var(--muted)', fontSize:10, fontWeight:700, letterSpacing:'.09em', textTransform:'uppercase', marginBottom:4, display:'block' }}>{label}</label>}
      {options ? (
        <select value={value} onChange={e=>onChange(e.target.value)} style={inputStyle}>
          <option value=''>— seleziona —</option>
          {options.map(o=><option key={o} value={o}>{o}</option>)}
        </select>
      ) : textarea ? (
        <textarea value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} rows={rows} style={inputStyle} />
      ) : (
        <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} style={inputStyle} />
      )}
    </div>
  )
}

// ─── Card ─────────────────────────────────────────────────────────────────────
export function Card({ children, style={}, ...props }) {
  return (
    <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:12, ...style }} {...props}>
      {children}
    </div>
  )
}

// ─── SectionTitle ─────────────────────────────────────────────────────────────
export function SecTitle({ children, style={} }) {
  return (
    <div style={{ color:'var(--muted)', fontSize:10, fontWeight:700, letterSpacing:'.1em', textTransform:'uppercase', marginBottom:10, ...style }}>
      {children}
    </div>
  )
}

// ─── Tag / Badge ──────────────────────────────────────────────────────────────
export function Tag({ children, color='var(--accent)', bg='var(--acclo)' }) {
  return (
    <span style={{ display:'inline-block', background:bg, color, border:`1px solid ${color}`, borderRadius:5, padding:'2px 8px', fontSize:10, fontWeight:800, letterSpacing:'.06em' }}>
      {children}
    </span>
  )
}

// ─── Avatar ───────────────────────────────────────────────────────────────────
export function Avatar({ name }) {
  return (
    <div style={{ width:38, height:38, borderRadius:'50%', background:'var(--acclo)', border:'1px solid var(--accent)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--accent)', fontWeight:900, fontSize:16, flexShrink:0, fontFamily:'var(--fontcd)' }}>
      {name ? name[0].toUpperCase() : '?'}
    </div>
  )
}

// ─── Empty state ──────────────────────────────────────────────────────────────
export function Empty({ children }) {
  return (
    <div style={{ background:'var(--card)', border:'1.5px dashed var(--border)', borderRadius:12, padding:28, textAlign:'center', color:'var(--muted)', fontSize:13, lineHeight:1.7 }}>
      {children}
    </div>
  )
}

// ─── Toast ────────────────────────────────────────────────────────────────────
export function Toast({ msg, onDone }) {
  React.useEffect(() => { const t = setTimeout(onDone, 2200); return () => clearTimeout(t) }, [])
  return (
    <div style={{ position:'fixed', bottom:80, left:'50%', transform:'translateX(-50%)', background:'var(--green)', color:'#fff', borderRadius:9, padding:'10px 20px', fontWeight:700, fontSize:13, zIndex:9999, whiteSpace:'nowrap', boxShadow:'0 4px 24px rgba(45,198,83,.4)', animation:'fadeIn .2s' }}>
      ✓ {msg}
    </div>
  )
}

// ─── Grid ─────────────────────────────────────────────────────────────────────
export function Grid({ cols=2, gap=10, children, style={} }) {
  return (
    <div style={{ display:'grid', gridTemplateColumns:`repeat(${cols},1fr)`, gap, ...style }}>
      {children}
    </div>
  )
}

// ─── Confirm modal ────────────────────────────────────────────────────────────
export function Confirm({ msg, onYes, onNo }) {
  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.75)', zIndex:8000, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }} onClick={onNo}>
      <div style={{ background:'var(--surface)', border:'1px solid var(--borderhi)', borderRadius:14, padding:24, maxWidth:340, width:'100%' }} onClick={e=>e.stopPropagation()}>
        <div style={{ fontSize:15, fontWeight:700, marginBottom:16, lineHeight:1.5 }}>{msg}</div>
        <div style={{ display:'flex', gap:10, justifyContent:'flex-end' }}>
          <Btn variant='ghost' onClick={onNo}>Annulla</Btn>
          <Btn variant='danger' onClick={onYes}>Conferma</Btn>
        </div>
      </div>
    </div>
  )
}
