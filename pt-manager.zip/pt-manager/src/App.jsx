import React, { useState, useEffect, useCallback } from 'react'
import { Toast, Confirm } from './components/UI.jsx'
import Dashboard from './views/Dashboard.jsx'
import Clients from './views/Clients.jsx'
import ClientDetail from './views/ClientDetail.jsx'
import { AllCards, Templates } from './views/CardsViews.jsx'
import CardEditor from './views/CardEditor.jsx'
import Settings from './views/Settings.jsx'
import { generateAndDownloadPDF } from './lib/pdf.js'
import {
  loadAll, persistClients, persistCards, persistTrainer,
  newClient, newCard, uid, now,
} from './lib/store.js'

const NAV = [
  { id:'dashboard', icon:'◈', label:'Home' },
  { id:'clients',   icon:'👤', label:'Clienti' },
  { id:'cards',     icon:'📋', label:'Schede' },
  { id:'templates', icon:'📑', label:'Template' },
  { id:'settings',  icon:'⚙️', label:'Impost.' },
]

export default function App() {
  const [data, setData] = useState(() => loadAll())
  const [view, setView] = useState('dashboard')
  const [activeClientId, setActiveClientId] = useState(null)
  const [activeCardId, setActiveCardId]     = useState(null)
  const [toast, setToast]   = useState(null)
  const [confirm, setConfirm] = useState(null) // {msg, onYes}

  // Persist on changes
  useEffect(() => { persistClients(data.clients) }, [data.clients])
  useEffect(() => { persistCards(data.cards) },     [data.cards])
  useEffect(() => { persistTrainer(data.trainer) },  [data.trainer])

  const showToast = (msg) => setToast(msg)
  const askConfirm = (msg, onYes) => setConfirm({ msg, onYes })

  // ── Getters ────────────────────────────────────────────────────────────────
  const activeClient   = data.clients.find(c => c.id === activeClientId) || null
  const activeCard     = data.cards.find(c => c.id === activeCardId) || null
  const templates      = data.cards.filter(c => c.isTemplate)
  const clientCards    = (cid) => data.cards.filter(c => c.clientId === cid && !c.isTemplate)

  // ── Navigation ─────────────────────────────────────────────────────────────
  const navigate = (v, params = {}) => {
    if (params.clientId !== undefined) setActiveClientId(params.clientId)
    if (params.cardId   !== undefined) setActiveCardId(params.cardId)
    setView(v)
    window.scrollTo(0, 0)
  }

  // ── Client CRUD ────────────────────────────────────────────────────────────
  const saveClient = (cl) => {
    setData(d => ({ ...d, clients: d.clients.find(c=>c.id===cl.id) ? d.clients.map(c=>c.id===cl.id?cl:c) : [...d.clients,cl] }))
    showToast('Cliente salvato')
  }

  const addNewClient = () => {
    const cl = newClient()
    setData(d => ({ ...d, clients: [...d.clients, cl] }))
    setActiveClientId(cl.id)
    setView('client-detail')
  }

  const deleteClient = (id) => {
    askConfirm('Eliminare il cliente e tutte le sue schede?', () => {
      setData(d => ({ ...d,
        clients: d.clients.filter(c=>c.id!==id),
        cards:   d.cards.filter(c=>c.clientId!==id),
      }))
      showToast('Cliente eliminato')
      navigate('clients')
    })
  }

  // ── Card CRUD ──────────────────────────────────────────────────────────────
  const saveCard = (card) => {
    const updated = { ...card, updatedAt: now() }
    setData(d => ({ ...d, cards: d.cards.find(c=>c.id===card.id) ? d.cards.map(c=>c.id===card.id?updated:c) : [...d.cards,updated] }))
    showToast('Scheda salvata')
  }

  const deleteCard = (id) => {
    askConfirm('Eliminare questa scheda?', () => {
      setData(d => ({ ...d, cards: d.cards.filter(c=>c.id!==id) }))
      showToast('Scheda eliminata')
    })
  }

  const cloneCard = (id, clientId) => {
    const card = data.cards.find(c=>c.id===id)
    if (!card) return
    const clone = { ...JSON.parse(JSON.stringify(card)), id:uid(), clientId, isTemplate:false,
      title: card.title + ' (copia)', createdAt:now(), updatedAt:now(),
      days: card.days.map(d=>({...d,id:uid(),exercises:d.exercises.map(e=>({...e,id:uid()}))}))
    }
    setData(d => ({ ...d, cards: [...d.cards, clone] }))
    showToast('Scheda duplicata')
  }

  const saveAsTemplate = (id) => {
    const card = data.cards.find(c=>c.id===id)
    if (!card) return
    const tmpl = { ...JSON.parse(JSON.stringify(card)), id:uid(), clientId:'', isTemplate:true,
      title: '[TEMPLATE] ' + card.title.replace('[TEMPLATE] ',''), createdAt:now(), updatedAt:now(),
      days: card.days.map(d=>({...d,id:uid(),exercises:d.exercises.map(e=>({...e,id:uid()}))}))
    }
    setData(d => ({ ...d, cards: [...d.cards, tmpl] }))
    showToast('Salvato come template')
  }

  const applyTemplate = (templateId, clientId) => {
    const tmpl = data.cards.find(c=>c.id===templateId)
    if (!tmpl) return
    const clone = { ...JSON.parse(JSON.stringify(tmpl)), id:uid(), clientId, isTemplate:false,
      title: tmpl.title.replace('[TEMPLATE] ',''), createdAt:now(), updatedAt:now(),
      days: tmpl.days.map(d=>({...d,id:uid(),exercises:d.exercises.map(e=>({...e,id:uid()}))}))
    }
    setData(d => ({ ...d, cards: [...d.cards, clone] }))
    setActiveCardId(clone.id)
    setView('card-editor')
    showToast('Template applicato')
  }

  const createCard = (clientId) => {
    const card = newCard(clientId)
    setData(d => ({ ...d, cards: [...d.cards, card] }))
    setActiveCardId(card.id)
    setView('card-editor')
  }

  const createTemplate = () => {
    const card = { ...newCard(''), isTemplate: true, title: 'Nuovo Template' }
    setData(d => ({ ...d, cards: [...d.cards, card] }))
    setActiveCardId(card.id)
    setView('card-editor')
  }

  // ── PDF ────────────────────────────────────────────────────────────────────
  const handlePDF = (cardId) => {
    const card   = data.cards.find(c=>c.id===cardId)
    const client = data.clients.find(c=>c.id===card?.clientId) || null
    if (!card) return
    try {
      generateAndDownloadPDF(card, client, data.trainer)
      showToast('PDF scaricato!')
    } catch(e) {
      console.error(e)
      showToast('Errore nella generazione PDF')
    }
  }

  // ── Trainer ────────────────────────────────────────────────────────────────
  const saveTrainer = (t) => {
    setData(d => ({ ...d, trainer: t }))
    showToast('Dati trainer salvati')
  }

  // ── Backup ─────────────────────────────────────────────────────────────────
  const handleExport = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type:'application/json' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `pt-manager-backup-${new Date().toISOString().slice(0,10)}.json`
    a.click()
  }

  const handleImport = (imported) => {
    askConfirm('Importare il backup? I dati attuali verranno sovrascritti.', () => {
      setData(d => ({
        clients: imported.clients || d.clients,
        cards:   imported.cards   || d.cards,
        trainer: imported.trainer || d.trainer,
      }))
      showToast('Backup importato')
      navigate('dashboard')
    })
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  const renderView = () => {
    switch (view) {
      case 'dashboard':
        return <Dashboard clients={data.clients} cards={data.cards} templates={templates} onNavigate={navigate} />

      case 'clients':
        return <Clients clients={data.clients} cards={data.cards} onNavigate={navigate} onAddClient={addNewClient} onDeleteClient={deleteClient} />

      case 'client-detail':
        return activeClient ? (
          <ClientDetail
            client={activeClient}
            cards={data.cards}
            templates={templates}
            trainer={data.trainer}
            onBack={() => navigate('clients')}
            onSaveClient={saveClient}
            onDeleteClient={deleteClient}
            onCreateCard={createCard}
            onOpenCard={(id) => { setActiveCardId(id); setView('card-editor'); }}
            onCloneCard={cloneCard}
            onSaveAsTemplate={saveAsTemplate}
            onApplyTemplate={applyTemplate}
            onDeleteCard={deleteCard}
            onGeneratePDF={handlePDF}
          />
        ) : null

      case 'cards':
        return <AllCards cards={data.cards} clients={data.clients}
          onOpenCard={(id) => { setActiveCardId(id); setView('card-editor'); }}
          onCloneCard={cloneCard} onSaveAsTemplate={saveAsTemplate}
          onDeleteCard={deleteCard} onGeneratePDF={handlePDF} />

      case 'templates':
        return <Templates templates={templates} clients={data.clients}
          onOpenCard={(id) => { setActiveCardId(id); setView('card-editor'); }}
          onApplyTemplate={applyTemplate} onDeleteCard={deleteCard}
          onCreateTemplate={createTemplate} />

      case 'card-editor':
        return activeCard ? (
          <CardEditor
            card={activeCard}
            client={data.clients.find(c=>c.id===activeCard.clientId)||null}
            trainer={data.trainer}
            onBack={() => {
              const cl = data.clients.find(c=>c.id===activeCard.clientId)
              if (cl) navigate('client-detail', { clientId: cl.id })
              else navigate(activeCard.isTemplate ? 'templates' : 'cards')
            }}
            onSave={saveCard}
            onGeneratePDF={handlePDF}
            onClone={cloneCard}
            onSaveAsTemplate={saveAsTemplate}
          />
        ) : null

      case 'settings':
        return <Settings trainer={data.trainer} clients={data.clients} cards={data.cards}
          templates={templates} onSaveTrainer={saveTrainer}
          onExport={handleExport} onImport={handleImport} />

      default:
        return null
    }
  }

  const mainViews = ['dashboard','clients','cards','templates','settings']

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100vh', height:'100dvh' }}>
      {/* Top bar */}
      <div style={{ background:'var(--surface)', borderBottom:'1px solid var(--border)', padding:'0 16px', display:'flex', alignItems:'center', height:52, gap:4, flexShrink:0, zIndex:100 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginRight:'auto' }}>
          <div style={{ background:'var(--accent)', color:'#fff', borderRadius:7, width:30, height:30, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--fontcd)', fontWeight:900, fontSize:14 }}>PT</div>
          <span style={{ fontFamily:'var(--fontcd)', fontWeight:900, fontSize:17, letterSpacing:'.02em' }}>Manager</span>
        </div>
        {/* Desktop nav */}
        <div style={{ display:'flex', gap:3 }} className='desktop-nav'>
          {NAV.map(n => (
            <button key={n.id} onClick={() => navigate(n.id)}
              style={{ background: view===n.id ? 'var(--acclo)' : 'transparent', border: `1px solid ${view===n.id?'var(--accent)':'transparent'}`, color: view===n.id?'var(--accent)':'var(--muted)', borderRadius:7, padding:'5px 12px', cursor:'pointer', fontSize:12.5, fontWeight:600, fontFamily:'var(--font)', display:'flex', alignItems:'center', gap:5 }}>
              {n.icon} {n.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ flex:1, overflowY:'auto', WebkitOverflowScrolling:'touch' }}>
        {renderView()}
      </div>

      {/* Mobile bottom nav */}
      <div style={{ background:'var(--surface)', borderTop:'1px solid var(--border)', display:'flex', flexShrink:0, paddingBottom:'env(safe-area-inset-bottom)' }} className='mobile-nav'>
        {NAV.map(n => (
          <button key={n.id} onClick={() => navigate(n.id)}
            style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:2, padding:'8px 4px', background:'transparent', border:'none', color: view===n.id?'var(--accent)':'var(--muted)', fontSize:9, fontWeight:700, letterSpacing:'.06em', textTransform:'uppercase', fontFamily:'var(--font)' }}>
            <span style={{ fontSize:19 }}>{n.icon}</span>
            {n.label}
          </button>
        ))}
      </div>

      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
      {confirm && <Confirm msg={confirm.msg} onYes={() => { confirm.onYes(); setConfirm(null); }} onNo={() => setConfirm(null)} />}

      <style>{`
        @media (min-width: 768px) {
          .mobile-nav { display: none !important; }
          .desktop-nav { display: flex !important; }
        }
        @media (max-width: 767px) {
          .desktop-nav { display: none !important; }
          .mobile-nav { display: flex !important; }
        }
      `}</style>
    </div>
  )
}
