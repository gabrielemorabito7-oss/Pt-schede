# PT Manager

Gestionale schede allenamento per personal trainer.
Stack: React + Vite + jsPDF. Deploy su Vercel in 3 minuti.

---

## 🚀 Deploy su Vercel (gratis, 3 minuti)

### Metodo 1 — Drag & Drop (più semplice)

1. Vai su [vercel.com](https://vercel.com) e crea un account gratuito
2. Dalla dashboard clicca **"Add New Project"**
3. Trascina l'intera cartella `pt-manager` nella finestra di Vercel
4. Vercel rileva automaticamente Vite/React — clicca **Deploy**
5. In 60 secondi hai il tuo URL tipo `pt-manager-gabri.vercel.app`

### Metodo 2 — GitHub (consigliato per aggiornamenti futuri)

1. Crea un repo su [github.com](https://github.com) (può essere privato)
2. Carica tutti i file del progetto
3. Su Vercel → "Import Git Repository" → seleziona il repo
4. Deploy automatico — ogni push aggiorna l'app

---

## 💻 Sviluppo locale

Installa [Node.js](https://nodejs.org) (versione 18+), poi:

```bash
cd pt-manager
npm install
npm run dev
```

Apri `http://localhost:5173`

---

## 📱 Installare come app su iPad

1. Apri l'URL Vercel in **Safari**
2. Tocca **Condividi ↑** → **"Aggiungi alla schermata Home"**
3. Dai il nome "PT Manager" → Aggiungi
4. Ora hai l'icona sul desktop come un'app vera

## 💻 Installare come app su Mac / PC

1. Apri l'URL in **Chrome** o **Edge**
2. Nella barra degli indirizzi compare un'icona di installazione
3. Clicca e installa — si apre come app standalone

---

## 📄 PDF

I PDF vengono scaricati direttamente sul dispositivo come file `.pdf`
con nome `NomeCliente_NomeScheda.pdf`.

---

## 🔒 Dati

I dati sono salvati nel **localStorage** del browser su ogni dispositivo.
Usa **Impostazioni → Esporta backup JSON** per fare backup
e **Importa backup JSON** per ripristinare o spostare dati tra dispositivi.

---

## Struttura progetto

```
pt-manager/
├── index.html
├── vite.config.js
├── package.json
├── public/
│   └── manifest.json
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── index.css
    ├── lib/
    │   ├── store.js      # state, localStorage, factories
    │   └── pdf.js        # generazione PDF con jsPDF
    ├── components/
    │   ├── UI.jsx         # componenti condivisi
    │   ├── ExerciseRow.jsx
    │   └── DayCard.jsx
    └── views/
        ├── Dashboard.jsx
        ├── Clients.jsx
        ├── ClientDetail.jsx
        ├── CardsViews.jsx
        ├── CardEditor.jsx
        └── Settings.jsx
```
